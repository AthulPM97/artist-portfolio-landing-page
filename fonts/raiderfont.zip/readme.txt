TrueTypeFont: Raiderfont
Version: 2.0
Dennis Ludlow Productions 2001 all rights reserved
Sharkshock Productions

This font goes out to all of the faithful that have been there for the heartbreak, triumph, and glory of the silver and black. Even if you're not a fan this makes a good headliner and alternate
typeface if you're tired of using the same bold ones over and over. Kerning has been added and several characters were resized and retweaked. Full character set. This font is free for personal use
only. There are many resources on the web if you're having trouble installing. If you're interested in licensing it commercially email me at dennis@sharkshock.net. I also design custom fonts and 
logos. 

visit www.sharkshock.net for more and take a bite out of boring design!
